console.log("Loaded");
function resetMessage() {
  var elemWrapper = document.getElementById("message"); 
  // elemWrapper.style.visibility = "hidden";
  elemWrapper.style.display = "none";
}
function beverage1Step1() {
  $(".btn-default").addClass("disable"); // disable btns
  var elemWrapper = document.getElementById("selection01"); 
  elemWrapper.style.display='block';
  var elem = document.getElementById("pgb1.1"); 
  var width = 0;
  var id = setInterval(frame, 50);
  function frame() {
    if (width >= 100) {
      beverage1Step2(); // call next step
      clearInterval(id);
      elem.textContent = 'Done';        
    } else {
        width++; 
        elem.style.width = width + '%'; 
        elem.textContent = width + '%';
    }
  }
    function beverage1Step2() {
    var elem = document.getElementById("pgb1.2"); 
    var width = 1;
    var id = setInterval(frame, 30);
    function frame() {
        if (width >= 100) {
          beverage1Step3(); // call next step
          clearInterval(id);
          elem.textContent = 'Done';  
        } else {
            width++; 
            elem.style.width = width + '%'; 
            elem.textContent = width + '%';  
        }
      }
  }
  function beverage1Step3() {
    var elem = document.getElementById("pgb1.3"); 
    var width = 1;
    var id = setInterval(frame, 60);
    function frame() {
        if (width >= 100) {
          beverage1Step4(); // call next step
          clearInterval(id);
          elem.textContent = 'Done';  
        } else {
            width++; 
            elem.style.width = width + '%'; 
            elem.textContent = width + '%';  
        }
      }
  }
  function beverage1Step4() {
    var elem = document.getElementById("pgb1.4"); 
    var width = 1;
    var id = setInterval(frame, 30);
    function frame() {
        if (width >= 100) {
          clearInterval(id);          
          elemWrapper.style.display='none';   
          $(".btn-default").removeClass("disable"); // enable btn           
            $('.loading-bar').width('0%'); // reset 
            $('.loading-bar').text(''); // reset 
          $('#message').show(); // drink ready 
          setTimeout(resetMessage, 3000); // reset message
            
        } else {
            width++; 
            elem.style.width = width + '%'; 
            elem.textContent = width + '%';  
        }
      }
  }
}
/* ↑↑↑ ↑↑↑ */
/* ↓↓↓ ↓↓↓ */
function beverage2Step1() {
  $(".btn-default").addClass("disable"); // disable btns
  var elemWrapper = document.getElementById("selection02"); 
  elemWrapper.style.display='block';
  var elem = document.getElementById("pgb2.1"); 
  var width = 0;
  var id = setInterval(frame, 50);
  function frame() {
    if (width >= 100) {
      beverage2Step2(); // call next step
      clearInterval(id);
      elem.textContent = 'Done';        
    } else {
        width++; 
        elem.style.width = width + '%'; 
        elem.textContent = width + '%';
    }
  }
    function beverage2Step2() {
    var elem = document.getElementById("pgb2.2"); 
    var width = 1;
    var id = setInterval(frame, 30);
    function frame() {
        if (width >= 100) {
          beverage2Step3(); // call next step
          clearInterval(id);
          elem.textContent = 'Done';  
        } else {
            width++; 
            elem.style.width = width + '%'; 
            elem.textContent = width + '%';  
        }
      }
  }
  function beverage2Step3() {
    var elem = document.getElementById("pgb2.3"); 
    var width = 1;
    var id = setInterval(frame, 60);
    function frame() {
        if (width >= 100) {
          beverage2Step4(); // call next step
          clearInterval(id);
          elem.textContent = 'Done';  
        } else {
            width++; 
            elem.style.width = width + '%'; 
            elem.textContent = width + '%';  
        }
      }
  }
  function beverage2Step4() {
    var elem = document.getElementById("pgb2.4"); 
    var width = 1;
    var id = setInterval(frame, 30);
    function frame() {
        if (width >= 100) {
          clearInterval(id);          
          elemWrapper.style.display='none';   
          $(".btn-default").removeClass("disable"); // enable btn           
            $('.loading-bar').width('0%'); // reset 
            $('.loading-bar').text(''); // reset 
          $('#message').show(); // drink ready 
          setTimeout(resetMessage, 3000); // reset message
            
        } else {
            width++; 
            elem.style.width = width + '%'; 
            elem.textContent = width + '%';  
        }
      }
  }
}
/* ↑↑↑ ↑↑↑ */
/* ↓↓↓ ↓↓↓ */
function beverage3Step1() {
  $(".btn-default").addClass("disable"); // disable btns
  var elemWrapper = document.getElementById("selection03"); 
  elemWrapper.style.display='block';
  var elem = document.getElementById("pgb3.1"); 
  var width = 0;
  var id = setInterval(frame, 50);
  function frame() {
    if (width >= 100) {
      beverage3Step2(); // call next step
      clearInterval(id);
      elem.textContent = 'Done';        
    } else {
        width++; 
        elem.style.width = width + '%'; 
        elem.textContent = width + '%';
    }
  }
    function beverage3Step2() {
    var elem = document.getElementById("pgb3.2"); 
    var width = 1;
    var id = setInterval(frame, 30);
    function frame() {
        if (width >= 100) {
          beverage3Step3(); // call next step
          clearInterval(id);
          elem.textContent = 'Done';  
        } else {
            width++; 
            elem.style.width = width + '%'; 
            elem.textContent = width + '%';  
        }
      }
  } 
  function beverage3Step3() {
    var elem = document.getElementById("pgb3.3"); 
    var width = 1;
    var id = setInterval(frame, 30);
    function frame() {
        if (width >= 100) {
          clearInterval(id);          
          elemWrapper.style.display='none';   
          $(".btn-default").removeClass("disable"); // enable btn           
            $('.loading-bar').width('0%'); // reset 
            $('.loading-bar').text(''); // reset 
          $('#message').show(); // drink ready 
          setTimeout(resetMessage, 3000); // reset message
            
        } else {
            width++; 
            elem.style.width = width + '%'; 
            elem.textContent = width + '%';  
        }
      }
  }
}














